<?php 
    if(!isset($_GET['id'])){
        echo "no se puede editar el profesional";
    }else{
        include 'model/conexion.php';
         $id = $_GET['id'];
         $consulta = $con->prepare("SELECT * FROM profesionales WHERE ID_PROFESIONAL=?;");
         $consulta ->execute([$id]);
         $profesional = $consulta->fetch(PDO::FETCH_OBJ);
         $consulta2 = $con->query("SELECT * FROM sucursal;");
         $sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);
    }

   

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
<?php include 'navbar.php' ?>
    <div class="container bg-white mt-3">
        <h1 class="text-center text-color-">Agenda de Profesionales</h1>
        <div class="content row vh-10 justify-content-center align-items-center">
            <h2 class="text-center">Edicion del Profesional</h2>
            <div class="col-auto">
            <form action="editar_profesional_proceso.php" method="POST" autocomplete="false">

                <div class="form-group">
                    <label for="Nombre">Nombre Completo:
                        <input class="form-control" type="text" name="Nombre_profesional" id="nombre_profesional_id" placeholder="Escribe el Nombre Completo" required value="<?php echo $profesional->NOMBRE_PROFESIONAL ?>">
                    </label>
                </div>
                <div class="form-group">
                <label style="margin-right: 10px;" for="">Sucursal:
                <select class="select-css" name="Sucursal_turno" id="Sucursal_turno" required>
                <?php foreach($sucursal as $dato2){?>
                <option id="Sucursal_turno" value="<?php echo $dato2->NOMBRE_SUCURSAL ?>"><?php echo $dato2->NOMBRE_SUCURSAL ?></option>
                <?php } ?>
                </select>
                </label>
                </div>
                <div class="form-group">
                    <label for="Telefono">Telefono
                        <input class="form-control" type="text" name="Telefono_profesional" id="telefono_profesional_id" placeholder="Escribe el Telefono" required value="<?php echo $profesional->TELEFONO_PROFESIONAL ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Email">Email
                        <input class="form-control" type="email" name="Email_profesional" id="email_profesional_id" placeholder="Escribe el Email" required value="<?php echo $profesional->EMAIL_PROFESIONAL ?>">
                    </label>
                </div>
                <div class="form-group">
                <input type="hidden" name="id3" value="<?php echo $profesional->ID_PROFESIONAL ?>" >
                <input class="btn btn-dark btn-md mb-3 mt-3" type="submit" value="Editar Profesional" name="Editar_pro">    
                </div>
                <a href="profesional.php" class="btn btn-md btn-dark mb-3">Regresar</a> 
            </form>
            </div>
        </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>