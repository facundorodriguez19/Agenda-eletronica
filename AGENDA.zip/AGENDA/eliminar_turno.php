<?php 
    if(!isset($_GET['id'])){
        header('Location: home.php');
    }else{
        include('model/conexion.php');
        $id = $_GET['id'];

        $consulta = $con -> prepare("DELETE FROM turnos WHERE ID_TURNO=?;");
        $result = $consulta->execute([$id]);
    
        if($result == true){
            header('Location: home.php');
        }else{
            echo "Error de Eliminacion";
        }

}

?>