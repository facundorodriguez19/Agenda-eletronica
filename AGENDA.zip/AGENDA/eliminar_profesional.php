<?php 
    if(!isset($_GET['id'])){
        header('Location: profesional.php');
    }else{
        include('model/conexion.php');
        $id = $_GET['id'];

        $consulta = $con -> prepare("DELETE FROM profesionales WHERE ID_PROFESIONAL=?;");
        $result = $consulta->execute([$id]);
    
        if($result == true){
            header('Location: profesional.php');
        }else{
            echo "error de Eliminacion";
        }

}

?>