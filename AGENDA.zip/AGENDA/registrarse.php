<?php
include 'model/conexion.php';

$consulta2 = $con->query("SELECT * FROM sucursal;");
$sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);


if (!empty($_POST['nombre_reg_usuario']) && !empty($_POST['regis_password'])) {
    $sql = "INSERT INTO usuarios(USUARIO, CLAVE, PERMISO, SUCURSAL) VALUES (:usuario, :clave, 'empleado',:sucursal)";
    $stmt = $con->prepare($sql);
    $stmt->bindParam(':usuario', $_POST['nombre_reg_usuario']);
    $password = password_hash($_POST['regis_password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':clave', $password);
    $stmt->bindParam(':sucursal', $_POST['Sucursal_turno']);



    if ($stmt->execute()) {
        $message = 'Nuevo Usuario Creado Correctamente';
    } else {
        $message = 'Usuario no creado';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos_login.css">
    <title>Register</title>
</head>

<body>

    <?php if (!empty($message)) : ?>
        <p><?= $message ?></p>
    <?php endif ?>
    <h1 class="margin_h1">Registrar:</h1>

    <form action="registrarse.php" method="POST">
        <input type="text" name="nombre_reg_usuario" placeholder="Ingrese su Nombre">
        <input type="password" name="regis_password" placeholder="Ingrese su Contraseña">
        <input type="password" name="confirm_password" placeholder="Confirma su Contraseña">
        <select class="select-css" style="text-align: center;margin: auto;margin-bottom: 8px;" name="Sucursal_turno" id="Sucursal_turno">
            <?php foreach ($sucursal as $dato2) { ?>
                <option id="Sucursal_turno" value="<?php echo $dato2->NOMBRE_SUCURSAL ?>"><?php echo $dato2->NOMBRE_SUCURSAL ?></option>
            <?php } ?>
        </select>
        <input type="submit" value="Enviar">
    </form>
    <span><a href="index.php">volver</a></span>
</body>

</html>