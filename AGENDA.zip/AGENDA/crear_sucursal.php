<?php
  if (isset($_POST['Agregar_sucursal'])){
    include 'model/conexion.php';
    $nombre=$_POST['Sucursal'];
    
    $consulta = $con->prepare("INSERT INTO sucursal(NOMBRE_SUCURSAL) VALUES(?);");    
    $result = $consulta->execute([$nombre]);
    if($result == true){
        header("Location: sucursal.php");
    }else{
        echo "no se pudo agregar el contacto";
    }
}
  
  

?>
