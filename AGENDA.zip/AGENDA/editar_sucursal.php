<?php 
    if(!isset($_GET['id'])){
        echo "no se puede editar la sucursal";
    }else{
        include 'model/conexion.php';
         $id = $_GET['id'];
         $consulta = $con->prepare("SELECT * FROM sucursal WHERE ID_SUCURSAL=?;");
         $consulta ->execute([$id]);
         $sucursal = $consulta->fetch(PDO::FETCH_OBJ);
         $consulta2 = $con->query("SELECT * FROM sucursal;");
         $sucursal2 = $consulta2->fetchAll(PDO::FETCH_OBJ);
    }


?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
<?php include 'navbar.php' ?>
    <div class="container bg-white mt-3">
        <h1 class="text-center text-color-">Agenda de Sucursales</h1>
        <div class="content row vh-10 justify-content-center align-items-center">
            <h2 class="text-center">Edicion de Sucrusal</h2>
            <div class="col-auto">
            <form action="editar_sucursal_proceso.php" method="POST" autocomplete="false">

                <div class="form-group">
                <label class="d-flex justify-content-center align-items-center" for="Nombre">Nombre:
                        <input class="form-control" type="text" name="Sucursal" id="sucursal" placeholder="Escribe la nueva Sucursal" required>
                    </label>
                </div>
                <div class="form-group">
                <input type="hidden" name="id4" value="<?php echo $sucursal->ID_SUCURSAL ?>" >
                <input class="btn btn-dark btn-md mb-3 mt-3" type="submit" value="Editar Sucursal" name="Editar_SUC">    
                </div>
            </form>
            </div>
        </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>