
<?php 
    try{
        $con = new PDO("mysql:host=localhost;dbname=agenda_estetica", "root","",
         array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"));
    }catch(Exception $e){
        echo "Hay error".$e->getMessage();
    }

?>
