<?php 
    if(!isset($_POST['Editar'])){
        header('Location: pacientes.php');
    }else{
        include('model/conexion.php');
        $cel=$_POST['Cedula'];
        $nom=$_POST['Nombre'];
        $apellido=$_POST['Apellido'];
        $tel=$_POST['Telefono'];
        $dir=$_POST['Direccion'];
        $email=$_POST['Email'];
        $id = $_POST['id2'];

        /*
        $tamaño_img = $_FILES['foto_antes']['size'];
        $tipo_img = $_FILES['foto_antes']['type'];
    
    
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
            $fefe = @getimagesize($_FILES['foto_antes']['tmp_name']);
            if ($fefe !== false) {
                $carpeta_destino = 'img/';
                $archivo_subir = $carpeta_destino . $_FILES['foto_antes']['name'];
                $pejfoe = $_FILES['foto_antes']['name'];
                move_uploaded_file($_FILES['foto_antes']['tmp_name'], $archivo_subir);
    
                }
            }
            */
        
            $tamaño_img2 = $_FILES['foto_despues']['size'];        
            $tipo_img2 = $_FILES['foto_despues']['type'];
    
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
                $rdrd = @getimagesize($_FILES['foto_despues']['tmp_name']);
                if ($rdrd !== false) {
                    $carpeta_destino2 = 'img/';
                    $archivo_subir2 = $carpeta_destino2 . $_FILES['foto_despues']['name'];
                    $pejfoe = $_FILES['foto_despues']['name'];
                    move_uploaded_file($_FILES['foto_despues']['tmp_name'], $archivo_subir2);
        
                }
            }
            

        
        $consulta = $con -> prepare("UPDATE pacientes SET CEDULA_PACIENTE=?, NOMBRE_PACIENTE=?, APELLIDO_PACIENTE=?, TELEFONO_PACIENTE=?, DIRECCION_PACIENTE=?, EMAIL_PACIENTE=?,FOTO_DESPUES_PACIENTE=? WHERE ID_PACIENTE=?;");
        $result = $consulta->execute([$cel,$nom,$apellido,$tel,$dir,$email,$archivo_subir2,$id]);
        
    if($result == true){
        header('Location: pacientes.php');
       
    }else{
        echo "error de actualizacion";
    }
    

}

?>