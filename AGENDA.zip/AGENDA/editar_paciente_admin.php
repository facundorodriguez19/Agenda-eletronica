<?php 
    if(!isset($_GET['id'])){
        echo "no se puede editar el paciente";
    }else{
        include 'model/conexion.php';
         $id = $_GET['id'];
         $consulta = $con->prepare("SELECT * FROM pacientes WHERE ID_PACIENTE=?;");
         $consulta ->execute([$id]);
         $paciente = $consulta->fetch(PDO::FETCH_OBJ);
    }


?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body style="background-color: #f2fbff;">
<?php include 'navbar.php' ?>
    <div class="container bg-white mt-3">
        <h1 class="text-center text-color-">Agenda de Pacientes</h1>
        <div class="content row vh-10 justify-content-center align-items-center">
            <h2 class="text-center">Edicion de Paciente</h2>
            <div class="col-auto">
            <form action="editar_paciente_proceso_admin.php" method="POST" autocomplete="false" enctype="multipart/form-data">

                <div class="form-group">
                    <label for="Cedula">Cedula
                        <input class="form-control" type="text" name="Cedula" id="cedula" placeholder="Escribe tu Cedula" required value="<?php echo $paciente->CEDULA_PACIENTE ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Nombre">Nombre
                        <input class="form-control" type="text" name="Nombre" id="nombre" placeholder="Escribe tu Nombre" required value="<?php echo $paciente->NOMBRE_PACIENTE ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Apellido">Apellido
                        <input class="form-control" type="text" name="Apellido" id="apellido" placeholder="Escribe tu Apellido" required value="<?php echo $paciente->APELLIDO_PACIENTE ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Telefono">Telefono/Celular
                        <input class="form-control" type="text" name="Telefono" id="telefono" placeholder="Escribe tu Telefono" required value="<?php echo $paciente->TELEFONO_PACIENTE ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Direccion">Direccion
                        <input class="form-control" type="text" name="Direccion" id="direccion" placeholder="Escribe tu Direccion" required value="<?php echo $paciente->DIRECCION_PACIENTE ?>">
                    </label>
                </div>
                <div class="form-group">
                    <label for="Email">Email
                        <input class="form-control" type="Email" name="Email" id="email" placeholder="Escribe tu Email" required value="<?php echo $paciente->EMAIL_PACIENTE ?>">
                    </label>
                </div>
                
                    <label for="Foto">
                        Foto Despues:
                        <input type="file" size="20" name="foto_despues" required>
                    </label>
               
                <div class="form-group">
                <input type="hidden" name="id2" value="<?php echo $paciente->ID_PACIENTE ?>" >
                <input class="btn btn-dark btn-md mb-3 mt-3" type="submit" value="Editar Paciente" name="Editar">    
                </div>
                <a href="pacientes_admin.php" class="btn btn-md btn-dark mb-3">Regresar</a> 
            </form>
            </div>
        </div>
    </div>
    
    <!--Fin de crar pacinete -->
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>