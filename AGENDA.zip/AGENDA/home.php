<?php
session_start();



include 'model/conexion.php';

$consulta1 = $con->query("SELECT * FROM pacientes;");
$paciente = $consulta1->fetchAll(PDO::FETCH_OBJ);

$consulta2 = $con->query("SELECT * FROM sucursal;");
$sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);

$consulta3 = $con->query("SELECT * FROM profesionales;");
$profesional = $consulta3->fetchAll(PDO::FETCH_OBJ);

$consulta4 = $con->query("SELECT * FROM equipo;");
$equipo = $consulta4->fetchAll(PDO::FETCH_OBJ);

$consulta5 = $con->query("SELECT * FROM tratamiento;");
$trata = $consulta5->fetchAll(PDO::FETCH_OBJ);

$consulta6 = $con->query("SELECT * FROM zona;");
$zona = $consulta6->fetchAll(PDO::FETCH_OBJ);

$consulta7 = $con->query("SELECT * FROM categorias_zonas;");
$categoria = $consulta7->fetchAll(PDO::FETCH_OBJ);

$consulta = $con->query("SELECT * FROM turnos ORDER BY HORA_INICIO ASC");
$turno = $consulta->fetchAll(PDO::FETCH_OBJ);



error_reporting(E_ERROR | E_WARNING | E_PARSE);

?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
  <link rel="stylesheet" href="css/estilos.css">


  <title>Reserva Turnos</title>
</head>


<body style="background-color: #f2fbff;">

  <?php include 'navbar.php' ?>

  <div style="padding-bottom: 50px;
    background-color: white;" class="d-lg-none"><img src="img/descarga (1).jpeg" class="img_inicio">
    <h3 style="padding-top: 20px;">&nbsp&nbspHola Usuario!!</h3>
    <a href="index.php" class="btn  btn_eliminar btn_salir"><samp style="font-family: ui-monospace !important;">Salir</samp> </a>
  </div>

  <div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
      <div class="container  mt-3 mb-5">
        <a class="btn d-none d-lg-block  btn_eliminar btn_salir btn_salir_lugar" href="index.php"><samp style="font-family: ui-monospace;">Cerrar</samp></a>
        <form id="form1" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
          <div class="row d-flex  justify-content-around">
            <div class="col-lg-4 col-12 mt-4 d-flex f justify-content-around">
              <div class="d-flex flex-column flex-lg-row flex-md-row justify-content-lg-between justify-content-center align-items-lg-end align-items-start form-group">




                <label for="Fecha">
                  <input class="form-control mr-3 botones_inicio mb-3" type="date" name="Fecha" id="fecha" value="<?= (isset($_POST['Fecha']) ? $_POST['Fecha'] : date("Y-m-d")); ?>">
                </label>



                <label for="Sucursal">
                  <select class="form-select botones_inicio mb-3" name="Sucursal_turno" id="Sucursal_turno" required>
                    <?php foreach ($sucursal as $dato2) {
                      if (isset($_POST["Sucursal_turno"]) && $_POST["Sucursal_turno"] == $dato2->NOMBRE_SUCURSAL)
                        echo '<option value="' . $dato2->NOMBRE_SUCURSAL . '" selected>' . $dato2->NOMBRE_SUCURSAL . ' </option>';
                      else
                        echo '<option value="' . $dato2->NOMBRE_SUCURSAL . '">' . $dato2->NOMBRE_SUCURSAL . ' </option>'; ?>

                    <?php } ?>
                  </select>
                </label>

                <label for="profesional">
                  <select class="form-select botones_inicio mb-3" name="Usuario_truno" id="Usuario_truno" required>
                    <?php foreach ($profesional as $dato3) {
                      if (isset($_POST["Usuario_truno"]) && $_POST["Usuario_truno"] == $dato3->NOMBRE_PROFESIONAL )
                        echo '<option value="' . $dato3->NOMBRE_PROFESIONAL . '" selected>' . $dato3->NOMBRE_PROFESIONAL . ' </option>';
                      else
                        echo '<option value="' . $dato3->NOMBRE_PROFESIONAL . '">' . $dato3->NOMBRE_PROFESIONAL . ' </option>';
                    ?>

                    <?php } ?>
                  </select>
                </label>

              </div>
            </div>
          </div>

          <input class="btn btn-dark boton_inicio mt-3" type="submit" id="filter" value="Filtrar datos" name="filtar">

        </form>
       
        <?php
       
        if (!isset($_POST["Sucursal_turno"]) and !isset($_POST["Usuario_truno"])) {
        ?>
          <script>
            window.onload = function() {
              document.getElementById("form1").submit();
            }
          </script>
          
        <?php
        }
        ?>
    
        <br><br>

        <div class="container tamaños">

          <?php

          $sucursalDrop = $_POST['Sucursal_turno'];
          $PROfesional = $_POST['Usuario_truno'];
          $fecha = $_POST['Fecha'];
          $libres = array();
          $hora_s = array(
            "08:00:00",
            "08:30:00",
            "09:00:00",
            "09:30:00",
            "10:00:00",
            "10:30:00",
            "11:00:00",
            "11:30:00",
            "12:00:00",
            "12:30:00",
            "13:00:00",
            "13:30:00",
            "14:00:00",
            "14:30:00",
            "15:00:00",
            "15:30:00",
            "16:00:00",
            "16:30:00",
            "17:00:00",
            "17:30:00",
            "18:00:00",
            "18:30:00",
            "19:00:00",
            "19:30:00",
            "20:00:00"
          );



          $x = 0;
          while ($x < 25) {

            $turnosFiltrados = array_filter($turno, function ($dato) use ($hora_s, $x, $sucursalDrop, $PROfesional, $fecha) {

              return ($dato->HORA_INICIO == $hora_s[$x]) && ($dato->NOMBRE_SUCURSAL == $sucursalDrop) && ($dato->FECHA == $fecha) && ($dato->PROFESIONAL == $PROfesional);
            });



            if ($turnosFiltrados) {

              foreach ($turnosFiltrados as $dato) {


          ?>

                <div class="card mb-3">
                  <div class="row g-0">

                    <div class="col-4 col-lg-2 d-flex px-3 py-3 justify-content-around align-items-center fechayhora  text-center">
                      <div style="color: white;">
                        <strong>
                          <?php
                          $time = strtotime($dato->FECHA);
                          //Primero capturar el dia de la semana siendo 1 lunes y 7 domingo
                          $day = date("N", $time);
                          //Ahora capturamos que fecha es 
                          $date = date("d", $time);
                          //Luego un switch para evaluar que dia es
                          switch ($day) {
                            case '1':
                              echo  $date . ' ' . 'Lunes';
                              break;
                            case '2':
                              echo $date  . ' ' . 'Martes';
                              break;
                            case '3':
                              echo $date  . ' ' . 'Miercoles';
                              break;
                            case '4':
                              echo $date  . ' ' . 'Jueves';
                              break;
                            case '5':
                              echo $date  . ' ' . 'Viernes';
                              break;
                            case '6':
                              echo $date  . ' ' . 'Sabado';
                              break;
                            case '7':
                              echo $date  . ' ' . 'Domingo';
                              break;
                            default:
                              // code...
                              break;
                          }


                          ?></strong><br><?php echo  substr($dato->HORA_INICIO, 0, -3); ?><br> a <br><?php echo substr($dato->HORA_FINAL, 0, -3); ?>
                      </div>
                    </div>
                    <div class="col-8 col-lg-10 d-flex justify-content-end ps-3">
                      <div class="row">
                        <div class="col-12">
                          <div class="pt-3 pe-3">
                            <h5 class="card-title">
                              <input type="checkbox" id="btn-modal2" value="">

                              <label for="btn-modal2" class="lbl-modal2" style="font-size:medium;color: fe8074;text-decoration-line: NONE;"><strong style="color: black;text-decoration-line: NONE;">Paciente:</strong>
                                <?php
                                $separador = "]";
                                $separador2 = "*";
                                $array_nombre_pa = explode($separador, $dato->DATOS_PACIENTE);
                                $array_nombre_pa2 = explode($separador2, $array_nombre_pa[0]);

                                echo  $array_nombre_pa2[1]; ?></label>

                                <label for="btn-modal2" class="lbl-modal2" style="font-size:medium;color: fe8074;text-decoration-line: NONE; padding-left:15vw;"><strong style="color: black;text-decoration-line: NONE;">Profesional:</strong>
                                <?php
                               

                                echo  $PROfesional;?></label>




                              <div class="modal2" style="z-index: 1;">
                                <div class="contenedor2">
                                  <header>Datos del Paciente</header>

                                  <label for="btn-modal2" style="position: absolute; color: white;"><i class="fas fa-times"></i></label>
                                  <div class="contenido2">
                                    <table>

                                      <tr>
                                        <td>Cedula:</td>
                                        <td><?php echo $dato->CEDULA_PACIENTE  ?></td>
                                      </tr>
                                      <tr>
                                        <td>Telefono:</td>
                                        <td><?php
                                            $separa = "-";
                                            $array_tele = explode($separa, $dato->DATOS_PACIENTE);

                                            echo substr($array_tele[0], -9);  ?></td>
                                      </tr>
                                      <tr>
                                        <td>Email:</td>
                                        <td><?php
                                            $sepa = "-";
                                            $sepa2 = "/";
                                            $array = explode($sepa, $dato->DATOS_PACIENTE);
                                            $array2 = explode($sepa2, $array[1]);
                                            echo $array2[0];
                                            ?></td>
                                      </tr>
                                      <tr>
                                        <td>Dirección:</td>
                                        <td><?php
                                            $separadores = "/";
                                            $separador_dire = "$";
                                            $array_dire = explode($separadores, $dato->DATOS_PACIENTE);
                                            $array_direccion = explode($separador_dire, $array_dire[1]);
                                            echo $array_direccion[0];
                                            ?></td>
                                      </tr>

                                      <tr>
                                        <th>Foto Antes:</th>
                                        <td><img src="<?php
                                                      $separador_img = "$";
                                                      $separador_img2 = "&";
                                                      $array_img = explode($separador_img, $dato->DATOS_PACIENTE);
                                                      $array_img2 = explode($separador_img2, $array_img[1]);
                                                      echo $array_img2[0];

                                                      ?>" alt="" width="60%" srcset=""></td>
                                      </tr>
                                      <!--  <tr>
                                      <th>Foto Despues:</th>
                                      <td><img src="<?php
                                                    // $separador_img_despues = "&";
                                                    //$array_img_des = explode($separador_img_despues, $dato->DATOS_PACIENTE);
                                                    //echo $array_img_des[1]; 
                                                    ?>" alt="" width="60%" srcset=""></td>
                                    </tr> -->

                                    </table>
                                  </div>
                                </div>
                              </div>
                            </h5>
                          </div>
                        </div>

                        <div class="row">
                          <div class="card-text tamaño_letra col-8 d-flex flex-row flex-lg-row flex-column align-items-start pb-3 px-3">
                            <div class="d-flex flex-row pe-lg-3 mb-2">

                              <div class="d-flex justify-content-center align-items-center">
                                <i title="Tratamiento" class="icon_agrandar fas fa-book-medical"></i>
                                <span class="icon_subir ps-1"> <?php echo $dato->TRATAMIENTO ?></span>
                              </div>
                            </div>

                            <div class="d-flex flex-row pe-lg-3 mb-2">

                              <div class="d-flex justify-content-center align-items-center">
                                <i title="Zona" style="color:yellow;" class=" icon_agrandar  fas fa-child"></i>
                                <span class="icon_subir ps-1">&nbsp<?php echo $dato->ZONA ?></span>
                              </div>
                            </div>

                            <div class="d-flex flex-row pe-lg-3">

                              <div class="d-flex justify-content-center align-items-center">
                                <i title="Equipo" class="icon_agrandar fas fa-microscope"></i>
                                <span class="icon_subir ps-1">&nbsp<?php echo $dato->EQUIPO ?> </span>
                              </div>
                            </div>

                          </div>

                          <div class="col-lg-4 col-md-4 col-12 d-flex justify-content-end align-items-end">
                            <a href="eliminar_turno.php?id=<?php echo $dato->ID_TURNO ?>" class=" btn btn_color btn_eliminar ">
                              <span class="cancelar ">Cancelar</span>
                            </a>
                          </div>



                        </div>

                      </div>
                    </div>

                  </div>
                </div>

              <?php
                switch ($dato->HORA_FINAL) {
                  case "08:00:00":
                    $x = 0;
                    break;
                  case "08:30:00":
                    $x = 1 - 1;
                    break;
                  case "09:00:00":
                    $x = 2 - 1;
                    break;
                  case "09:30:00":
                    $x = 3 - 1;
                    break;
                  case "10:00:00":
                    $x = 4 - 1;
                    break;
                  case "10:30:00":
                    $x = 5 - 1;
                    break;
                  case "11:00:00":
                    $x = 6 - 1;
                    break;
                  case "11:30:00":
                    $x = 7 - 1;
                    break;
                  case "12:00:00":
                    $x = 8 - 1;
                    break;
                  case "12:30:00":
                    $x = 9 - 1;
                    break;
                  case "13:00:00":
                    $x = 10 - 1;
                    break;
                  case "13:30:00":
                    $x = 11 - 1;
                    break;
                  case "14:00:00":
                    $x = 12 - 1;
                    break;
                  case "14:30:00":
                    $x = 13 - 1;
                    break;
                  case "15:00:00":
                    $x = 14 - 1;
                    break;
                  case "15:30:00":
                    $x = 15 - 1;
                    break;
                  case "16:00:00":
                    $x = 16 - 1;
                    break;
                  case "16:30:00":
                    $x = 17 - 1;
                    break;
                  case "17:00:00":
                    $x = 18 - 1;
                    break;
                  case "17:30:00":
                    $x = 19 - 1;
                    break;
                  case "18:00:00":
                    $x = 20 - 1;
                    break;
                  case "18:30:00":
                    $x = 21 - 1;
                    break;
                  case "19:00:00":
                    $x = 22 - 1;
                    break;
                  case "19:30:00":
                    $x = 23 - 1;
                    break;
                  case "20:00:00":
                    $x = 24;
                    break;
                }
              }
            } else {
              ?>

              <div class="card mb-3 estilos_tiempoLibre">
                <div class="row g-0">
                  <div class="col-4 col-lg-2 d-flex  justify-content-around align-items-center estilo_horas_turnoLibre">
                    <div class="estilo_horas_tiempoLibre"><?php echo substr($hora_s[$x], 0, -3); ?></div>
                  </div>
                  <div class=" col-8 col-lg-10">
                    <div class="card-body">
                      <h5 class="card-title" style="text-align: center; color:white;transform: translateX(-40%);margin-left: 34%;">TURNO LIBRE</h5>
                    </div>
                  </div>
                </div>
              </div>

              <input type="checkbox" id="btn-modal" value="">
              <div class="d-flex flex-row justify-content-center">
                <label for="btn-modal" class="d-flex boton_modal btn-success" style="background-color: #4ed4bb; margin-left: 10px;"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIw%0D%0AMDAvc3ZnIj4KCiA8Zz4KICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+CiAgPHJlY3QgZmlsbD0i%0D%0Abm9uZSIgaWQ9ImNhbnZhc19iYWNrZ3JvdW5kIiBoZWlnaHQ9IjQwMiIgd2lkdGg9IjU4MiIgeT0i%0D%0ALTEiIHg9Ii0xIi8+CiA8L2c+CiA8Zz4KICA8dGl0bGU+TGF5ZXIgMTwvdGl0bGU+CiAgPHBvbHln%0D%0Ab24gc3Ryb2tlPSIjZmZmZmZmIiBpZD0ic3ZnXzEiIHBvaW50cz0iODAuMiw1MS42IDUxLjQsNTEu%0D%0ANiA1MS40LDIyLjYgNDguOSwyMi42IDQ4LjksNTEuNiAxOS45LDUxLjYgMTkuOSw1NC4xIDQ4Ljks%0D%0ANTQuMSA0OC45LDgzLjEgICA1MS40LDgzLjEgNTEuNCw1NC4xIDgwLjQsNTQuMSA4MC40LDUxLjYg%0D%0AIiBmaWxsPSIjZmZmZmZmIi8+CiA8L2c+Cjwvc3ZnPg==" class="menu__trigger"></label>
              </div>
              <div class="modal ">
                <div class="contenedor">
                  <header>Agendar Turno</header>

                  <label for="btn-modal" style="position: absolute; color: white;"><i class="fas fa-times"></i></label>
                  <div class="contenido">

                    <form id="form2" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" autocomplete="false">
                      <div class="form-group d-flex flex-column">


                        <label for="">Fecha de Hoy:
                          <input class="form-control" type="date" name="Fecha" id="fecha" placeholder="Fecha" value="<?php echo date("Y-m-d"); ?>" required>
                        </label><br>


                        <label class="d-flex " for="">Pacientes:
                          <select class="select-css" name="Paciente_turno" id="Paciente_turno">
                            <?php foreach ($paciente as $date) { ?>
                              <option id="Paciente_turno" value="<?php
                                                                  echo $date->CEDULA_PACIENTE;
                                                                  echo "*";
                                                                  echo $date->NOMBRE_PACIENTE;
                                                                  echo " ";
                                                                  echo $date->APELLIDO_PACIENTE;
                                                                  echo "]";
                                                                  echo $date->TELEFONO_PACIENTE;
                                                                  echo "-";
                                                                  echo $date->EMAIL_PACIENTE;
                                                                  echo "/";
                                                                  echo $date->DIRECCION_PACIENTE;
                                                                  echo "$";
                                                                  echo $date->FOTO_ANTES_PACIENTE;
                                                                  echo "&";
                                                                  echo $date->FOTO_DESPUES_PACIENTE;

                                                                  ?>"><?php echo $date->NOMBRE_PACIENTE ?> <?php echo $date->APELLIDO_PACIENTE ?> </option>
                            <?php } ?>
                          </select>
                        </label><br>


                        <label class="d-flex " for="">Sucursal:
                          <select class="select-css" name="Sucursal_turno" id="Sucursal_turno" required>
                            <?php foreach ($sucursal as $dato2) { ?>
                              <option id="Sucursal_turno" value="<?php echo $dato2->NOMBRE_SUCURSAL ?>"><?php echo $dato2->NOMBRE_SUCURSAL ?></option>
                            <?php } ?>
                          </select>
                        </label><br>

                        <label class="d-flex " for="profesional">Profesional:
                          <select class="select-css" name="profesional_truno" id="profesional_truno" required>
                            <?php foreach ($profesional as $dato3) { ?>
                              <option id="profesional_truno" value="<?php echo $dato3->NOMBRE_PROFESIONAL ?>"><?php echo $dato3->NOMBRE_PROFESIONAL ?></option>
                            <?php } ?>
                          </select>
                        </label><br>

                        <label class="d-flex " for="Hora_Inicial">Hora Inicial:
                          <select class="select-css" name="Hora_Inicial" id="Hora_Inicial" required>
                            <option value="08:00:00">08:00</option>
                            <option value="08:30:00">08:30</option>
                            <option value="09:00:00">09:00</option>
                            <option value="09:30:00">09:30</option>
                            <option value="10:00:00">10:00</option>
                            <option value="10:30:00">10:30</option>
                            <option value="11:00:00">11:00</option>
                            <option value="11:30:00">11:30</option>
                            <option value="12:00:00">12:00</option>
                            <option value="12:30:00">12:30</option>
                            <option value="13:00:00">13:00</option>
                            <option value="13:30:00">13:30</option>
                            <option value="14:00:00">14:00</option>
                            <option value="14:30:00">14:30</option>
                            <option value="15:00:00">15:00</option>
                            <option value="15:30:00">15:30</option>
                            <option value="16:00:00">16:00</option>
                            <option value="16:30:00">16:30</option>
                            <option value="17:00:00">17:00</option>
                            <option value="17:30:00">17:30</option>
                            <option value="18:00:00">18:00</option>
                            <option value="18:30:00">18:30</option>
                            <option value="19:00:00">19:00</option>
                            <option value="19:30:00">19:30</option>
                            <option value="20:00:00">20:00</option>
                          </select>
                        </label><br>

                        <label class="d-flex " for="Hora_Final">Hora Final:
                          <select class="select-css" name="Hora_Final" id="Hora_Final" required>
                            <option value="08:00:00">08:00</option>
                            <option value="08:30:00">08:30</option>
                            <option value="09:00:00">09:00</option>
                            <option value="09:30:00">09:30</option>
                            <option value="10:00:00">10:00</option>
                            <option value="10:30:00">10:30</option>
                            <option value="11:00:00">11:00</option>
                            <option value="11:30:00">11:30</option>
                            <option value="12:00:00">12:00</option>
                            <option value="12:30:00">12:30</option>
                            <option value="13:00:00">13:00</option>
                            <option value="13:30:00">13:30</option>
                            <option value="14:00:00">14:00</option>
                            <option value="14:30:00">14:30</option>
                            <option value="15:00:00">15:00</option>
                            <option value="15:30:00">15:30</option>
                            <option value="16:00:00">16:00</option>
                            <option value="16:30:00">16:30</option>
                            <option value="17:00:00">17:00</option>
                            <option value="17:30:00">17:30</option>
                            <option value="18:00:00">18:00</option>
                            <option value="18:30:00">18:30</option>
                            <option value="19:00:00">19:00</option>
                            <option value="19:30:00">19:30</option>
                            <option value="20:00:00">20:00</option>
                          </select>
                        </label><br>

                        <label class="d-flex " for="tratamiento">Tratamiento:
                          <select class="select-css" name="Tratamiento" id="" required>
                            <?php foreach ($trata as $dato5) { ?>
                              <option id="Tratamiento" value="<?php echo $dato5->NOMBRE_TRATA ?>"><?php echo $dato5->NOMBRE_TRATA ?></option>
                            <?php } ?>
                          </select>
                        </label><br>

                        <label class="d-flex " for="equipo">Equipo:
                          <select class="select-css" name="Equipo" id="" required>
                            <?php foreach ($equipo as $dato4) { ?>
                              <option id="Equipo" value="<?php echo $dato4->NOMBRE_EQUIPO ?>"><?php echo $dato4->NOMBRE_EQUIPO ?></option>
                            <?php } ?>
                          </select>
                        </label><br>



                        <label class="d-flex " for="zona">Zonas:
                          <select class="select-css parte_zona" name="Zona" id="" multiple required>
                            <?php foreach ($zona as $dato6) { ?>
                              <option id="Zona" value="<?php echo $dato6->NOMBRE_ZONA ?>"><?php echo $dato6->NOMBRE_ZONA ?></option>
                            <?php } ?>
                          </select>
                        </label><br>

                        <label class="d-flex" for="Comentarios">Comentarios:
                          <textarea style="    width: 76%;" name="Comentario" id="" cols="15" rows="1"></textarea>
                        </label>

                        <input class="  btn btn-dark btn-md mb-3 mt-3 btn_color_agregar" style="margin-left: -20px;margin-right: -20px;" type="submit" id="turno" value="Agendar Turno" name="Turno">
                      </div>


                    </form>
                  </div>
                </div>
              </div>





          <?php

            }
            $x++;
          } ?>


        </div>
      </div>
    </div>


  </div>



  <?php

  if (isset($_POST['Turno'])) {
    include 'model/conexion.php';


    $cedula = $_POST['Paciente_turno'];
    $sucursal = $_POST['Sucursal_turno'];
    $pacientename = $_POST['Paciente_turno'];
    $usuario = $_POST['profesional_truno'];

    $hora_ini = $_POST['Hora_Inicial'];
    $hora_fin = $_POST['Hora_Final'];
    $trata = $_POST['Tratamiento'];
    $zona = $_POST['Zona'];
    $equipo = $_POST['Equipo'];
    $fecha = $_POST['Fecha'];
    $coment = $_POST['Comentario'];


/*

      if ($query->rowCount() > 10) {
  ?>
      <div class="alert">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        ERROR: Existe un turno ya registrado en esos horarios, turno NO registrado.
      </div>
    <?php
    } else {

*/


    $sql = "SELECT * FROM turnos WHERE  NOMBRE_SUCURSAL = '$sucursal'";
    $query = $con->prepare($sql);
    $query->execute();

  
if ($hora_ini<$hora_fin){

      $sql1 = "INSERT INTO turnos(FECHA,DATOS_PACIENTE,CEDULA_PACIENTE,NOMBRE_SUCURSAL,PROFESIONAL,HORA_INICIO,HORA_FINAL,TRATAMIENTO,EQUIPO,ZONA,COMENTARIOS) VALUES ('$fecha','$pacientename','$cedula','$sucursal','$usuario','$hora_ini','$hora_fin','$trata','$equipo','$zona','$coment')";
      $consulta = $con->prepare($sql1);
      $consulta->execute();
    ?>
      <script>
        window.onload = function() {
          document.getElementById("form1").submit();
          delay(100);
        }
      </script>
      <div class="alert-success">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        Turno creado con exito!
      </div>

  <?php
       } else {  ?>
        <div class="alert">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        ERROR: El horaio inicial siempre debe ser menor que el horario final.
      </div>
 <?php
       }
       
    
  }
  ?>




  <script src="alert.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>