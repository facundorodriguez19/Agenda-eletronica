<?php
include 'model/conexion.php';
$consulta = $con->query("SELECT * FROM profesionales;");
$profesional = $consulta->fetchAll(PDO::FETCH_OBJ);

$consulta2 = $con->query("SELECT * FROM sucursal;");
$sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    <?php include 'navbar.php' ?>
    <input type="checkbox" id="btn-modal" value="">
    <div class="d-flex flex-row justify-content-center">
        <label for="btn-modal" class="d-flex boton_modal  btn-success" style="background-color: #4ed4bb;"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIw%0D%0AMDAvc3ZnIj4KCiA8Zz4KICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+CiAgPHJlY3QgZmlsbD0i%0D%0Abm9uZSIgaWQ9ImNhbnZhc19iYWNrZ3JvdW5kIiBoZWlnaHQ9IjQwMiIgd2lkdGg9IjU4MiIgeT0i%0D%0ALTEiIHg9Ii0xIi8+CiA8L2c+CiA8Zz4KICA8dGl0bGU+TGF5ZXIgMTwvdGl0bGU+CiAgPHBvbHln%0D%0Ab24gc3Ryb2tlPSIjZmZmZmZmIiBpZD0ic3ZnXzEiIHBvaW50cz0iODAuMiw1MS42IDUxLjQsNTEu%0D%0ANiA1MS40LDIyLjYgNDguOSwyMi42IDQ4LjksNTEuNiAxOS45LDUxLjYgMTkuOSw1NC4xIDQ4Ljks%0D%0ANTQuMSA0OC45LDgzLjEgICA1MS40LDgzLjEgNTEuNCw1NC4xIDgwLjQsNTQuMSA4MC40LDUxLjYg%0D%0AIiBmaWxsPSIjZmZmZmZmIi8+CiA8L2c+Cjwvc3ZnPg==" class="menu__trigger"></label>
    </div>
    <div class="modal">
        <div class="contenedor">
            <header>Agregar Profecional</header>

            <label for="btn-modal" style="position: absolute; color: white;"><i class="fas fa-times"></i></label>
            <div class="contenido">
                <form action="crear_profesional.php" method="POST" autocomplete="false">
                <div class="d-flex flex-column">
                        <label class="d-flex justify-content-center align-items-center" for="Nombre">Nombre:&nbsp&nbsp
                            <input class="form-control" type="text" name="nombre_profesional" id="nombre_profesional_id" placeholder="Escribe tu Nombre Completo" required>
                        </label>
                    
                        <label  class="d-flex justify-content-center align-items-center select_tamaño" style="margin-right: 10px;" for="">Sucursal:&nbsp&nbsp&nbsp
                            <select class="select-css" name="Sucursal_turno" id="Sucursal_turno" required>
                                <?php foreach ($sucursal as $dato2) { ?>
                                    <option id="Sucursal_turno" value="<?php echo $dato2->NOMBRE_SUCURSAL ?>"><?php echo $dato2->NOMBRE_SUCURSAL ?></option>
                                <?php } ?>
                            </select>
                        </label>
                   
                        <label style="margin-top: 5px;margin-bottom: 5px;" class="d-flex justify-content-center align-items-center" for="Telefono">Telefono:
                            <input class="form-control" type="text" name="telefono_profesional" id="telefono_profesional_id" placeholder="Escribe tu Telefono" required>
                        </label>
                   
                        <label class="d-flex justify-content-center align-items-center" for="email">Email:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                            <input class="form-control" type="email" name="email_profesional" id="email_profesional_id" placeholder="Escribe tu Email" required>
                        </label>
                   
                        <input class="btn  btn-md mb-3 mt-3 btn_color_agregar posicion_btn_agregar_paciente" style="top: 390px !important ;" type="submit" value="Agregar Profesional" name="Agregar_Profesional">
                        </div>
                        </div>
                </form>

            
        </div>
    </div>



            <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////-->

        
                <div class="container bg-white mt-3">
                    <h2 class="text-center">Profesionales Existentes</h2>
                    <div class="content">
                        <table style="margin:auto; width:70%; margin-bottom: 5vw;" class="table d-lg-block d-none table-hover table-bordered bg-light text-black">
                            <thead>
                                <th style="font-size: 23px;">Nombre Completo</th>
                                <th style="font-size: 23px;">Sucursal</th>
                                <th style="font-size: 23px;">Telefono</th>
                                <th style="font-size: 23px;">Email</th>
                             
                                <th style="margin:auto; width:12%; font-size: 23px;">Acciones</th>

                            </thead>
                            <tbody>
                                <?php
                                foreach ($profesional as $dato) {
                                ?>
                                    <tr style="background:white;">
                                        <td style="font-size: 20px;"><?php echo $dato->NOMBRE_PROFESIONAL ?></td>
                                        <td style="font-size: 20px;"><?php echo $dato->SUCURSAL_PROFESIONAL ?></td>
                                        <td style="font-size: 20px;"><?php echo $dato->TELEFONO_PROFESIONAL ?></td>
                                        <td style="font-size: 20px;"><?php echo $dato->EMAIL_PROFESIONAL ?></td>
                                       
                                        <td class="d-flex flex-row flex-nowrap"><a href="editar_profesional.php?id=<?php echo $dato->ID_PROFESIONAL ?>" class="btn btn-warning me-1"><i class="fas fa-marker"></i></a> <a href="eliminar_profesional.php?id=<?php echo $dato->ID_PROFESIONAL ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <table class=" d-lg-none d-block table table-bordered bg-light text-black">
                            <thead>
                                <th style="font-size: 16px;">Nombre</th>
                                <th style="font-size: 16px;">Sucursal</th>
                                <th style="margin:auto; width:12%; font-size: 16px;">Acciones</th>

                            </thead>
                            <tbody>
                                <?php
                                foreach ($profesional as $dato) {
                                ?>
                                    <tr style="background:white;">
                                        <td style="font-size: 14px;"><?php echo $dato->NOMBRE_PROFESIONAL ?></td>
                                        <td style="font-size: 14px;"><?php echo $dato->SUCURSAL_PROFESIONAL ?></td>
                                        <td class="d-flex flex-row flex-nowrap"><a href="editar_profesional.php?id=<?php echo $dato->ID_PROFESIONAL ?>" class="btn btn-warning me-1"><i class="fas fa-marker"></i></a> <a href="eliminar_profesional.php?id=<?php echo $dato->ID_PROFESIONAL ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a></td>
                                    </tr>

                                <?php } ?>
                            </tbody>
                        </table>

                    </div>
                </div>
         
       



        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>