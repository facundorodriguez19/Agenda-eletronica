<?php

include 'model/conexion.php';

$consulta1 = $con->query("SELECT * FROM pacientes;");
$paciente = $consulta1->fetchAll(PDO::FETCH_OBJ);

$consulta2 = $con->query("SELECT * FROM sucursal;");
$sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);

$consulta3 = $con->query("SELECT * FROM profesionales;");
$profesional = $consulta3->fetchAll(PDO::FETCH_OBJ);

$consulta4 = $con->query("SELECT * FROM equipo;");
$equipo = $consulta4->fetchAll(PDO::FETCH_OBJ);

$consulta5 = $con->query("SELECT * FROM tratamiento;");
$trata = $consulta5->fetchAll(PDO::FETCH_OBJ);

$consulta6 = $con->query("SELECT * FROM zona;");
$zona = $consulta6->fetchAll(PDO::FETCH_OBJ);

$consulta7 = $con->query("SELECT * FROM categorias_zonas;");
$categoria = $consulta7->fetchAll(PDO::FETCH_OBJ);

$consulta = $con->query("SELECT * FROM turnos ORDER BY HORA_INICIO ASC");
$turno = $consulta->fetchAll(PDO::FETCH_OBJ);



error_reporting(E_ERROR | E_WARNING | E_PARSE);

?>

<input type="checkbox" id="btn-modal" value="">
                    <div class="d-flex flex-row justify-content-center">
                      <label for="btn-modal" class="d-flex boton_modal  btn-success" style="background-color: #4ed4bb;"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIw%0D%0AMDAvc3ZnIj4KCiA8Zz4KICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+CiAgPHJlY3QgZmlsbD0i%0D%0Abm9uZSIgaWQ9ImNhbnZhc19iYWNrZ3JvdW5kIiBoZWlnaHQ9IjQwMiIgd2lkdGg9IjU4MiIgeT0i%0D%0ALTEiIHg9Ii0xIi8+CiA8L2c+CiA8Zz4KICA8dGl0bGU+TGF5ZXIgMTwvdGl0bGU+CiAgPHBvbHln%0D%0Ab24gc3Ryb2tlPSIjZmZmZmZmIiBpZD0ic3ZnXzEiIHBvaW50cz0iODAuMiw1MS42IDUxLjQsNTEu%0D%0ANiA1MS40LDIyLjYgNDguOSwyMi42IDQ4LjksNTEuNiAxOS45LDUxLjYgMTkuOSw1NC4xIDQ4Ljks%0D%0ANTQuMSA0OC45LDgzLjEgICA1MS40LDgzLjEgNTEuNCw1NC4xIDgwLjQsNTQuMSA4MC40LDUxLjYg%0D%0AIiBmaWxsPSIjZmZmZmZmIi8+CiA8L2c+Cjwvc3ZnPg==" class="menu__trigger"></label>
                    </div >
                      <div class="modal ">
                        <div class="contenedor">
                          <header>Agendar Turno</header>

                          <label for="btn-modal" style="position: absolute; color: white;"><i class="fas fa-times"></i></label>
                          <div class="contenido">

                            <form id="form2" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" autocomplete="false">
                              <div class="form-group d-flex flex-column">


                                <label for="">Fecha de Hoy:
                                  <input class="form-control" type="date" name="Fecha" id="fecha" placeholder="Fecha" value="<?php echo date("Y-m-d"); ?>" required>
                                </label><br>


                                <label class="d-flex " for="">Pacientes:
                                  <select class="select-css" name="Paciente_turno" id="Paciente_turno">
                                    <?php foreach ($paciente as $date) { ?>
                                      <option id="Paciente_turno" value="<?php
                                                                          echo $date->CEDULA_PACIENTE;                           
                                                                          echo $date->NOMBRE_PACIENTE;
                                                                          echo " ";
                                                                          echo $date->APELLIDO_PACIENTE;
                                                                          echo $date->TELEFONO_PACIENTE;
                                                                          echo "-";
                                                                          echo $date->EMAIL_PACIENTE;
                                                                          echo "/";
                                                                          echo $date->DIRECCION_PACIENTE;
                                                                          echo "$";
                                                                          echo $date->FOTO_ANTES_PACIENTE;
                                                                          echo "&";
                                                                          echo $date->FOTO_DESPUES_PACIENTE;
                                                                         
                                                                           ?>"><?php echo $date->NOMBRE_PACIENTE ?> <?php echo $date->APELLIDO_PACIENTE ?> </option>
                                    <?php } ?>
                                  </select>
                                </label><br>


                                <label class="d-flex " for="">Sucursal:
                                  <select class="select-css" name="Sucursal_turno" id="Sucursal_turno" required>
                                    <?php foreach ($sucursal as $dato2) { ?>
                                      <option id="Sucursal_turno" value="<?php echo $dato2->NOMBRE_SUCURSAL ?>"><?php echo $dato2->NOMBRE_SUCURSAL ?></option>
                                    <?php } ?>
                                  </select>
                                </label><br>

                                <label class="d-flex " for="profesional">Profesional:
                                  <select class="select-css" name="profesional_truno" id="profesional_truno" required>
                                    <?php foreach ($profesional as $dato3) { ?>
                                      <option id="profesional_truno" value="<?php echo $dato3->NOMBRE_PROFESIONAL ?>"><?php echo $dato3->NOMBRE_PROFESIONAL ?></option>
                                    <?php } ?>
                                  </select>
                                </label><br>

                                <label class="d-flex " for="Hora_Inicial">Hora Inicial:
                                  <select class="select-css" name="Hora_Inicial" id="Hora_Inicial" required>
                                    <option value="08:00:00">08:00</option>
                                    <option value="08:30:00">08:30</option>
                                    <option value="09:00:00">09:00</option>
                                    <option value="09:30:00">09:30</option>
                                    <option value="10:00:00">10:00</option>
                                    <option value="10:30:00">10:30</option>
                                    <option value="11:00:00">11:00</option>
                                    <option value="11:30:00">11:30</option>
                                    <option value="12:00:00">12:00</option>
                                    <option value="12:30:00">12:30</option>
                                    <option value="13:00:00">13:00</option>
                                    <option value="13:30:00">13:30</option>
                                    <option value="14:00:00">14:00</option>
                                    <option value="14:30:00">14:30</option>
                                    <option value="15:00:00">15:00</option>
                                    <option value="15:30:00">15:30</option>
                                    <option value="16:00:00">16:00</option>
                                    <option value="16:30:00">16:30</option>
                                    <option value="17:00:00">17:00</option>
                                    <option value="17:30:00">17:30</option>
                                    <option value="18:00:00">18:00</option>
                                    <option value="18:30:00">18:30</option>
                                    <option value="19:00:00">19:00</option>
                                    <option value="19:30:00">19:30</option>
                                    <option value="20:00:00">20:00</option>
                                  </select>
                                </label><br>

                                <label class="d-flex " for="Hora_Final">Hora Final:
                                  <select class="select-css" name="Hora_Final" id="Hora_Final" required>
                                    <option value="08:00:00">08:00</option>
                                    <option value="08:30:00">08:30</option>
                                    <option value="09:00:00">09:00</option>
                                    <option value="09:30:00">09:30</option>
                                    <option value="10:00:00">10:00</option>
                                    <option value="10:30:00">10:30</option>
                                    <option value="11:00:00">11:00</option>
                                    <option value="11:30:00">11:30</option>
                                    <option value="12:00:00">12:00</option>
                                    <option value="12:30:00">12:30</option>
                                    <option value="13:00:00">13:00</option>
                                    <option value="13:30:00">13:30</option>
                                    <option value="14:00:00">14:00</option>
                                    <option value="14:30:00">14:30</option>
                                    <option value="15:00:00">15:00</option>
                                    <option value="15:30:00">15:30</option>
                                    <option value="16:00:00">16:00</option>
                                    <option value="16:30:00">16:30</option>
                                    <option value="17:00:00">17:00</option>
                                    <option value="17:30:00">17:30</option>
                                    <option value="18:00:00">18:00</option>
                                    <option value="18:30:00">18:30</option>
                                    <option value="19:00:00">19:00</option>
                                    <option value="19:30:00">19:30</option>
                                    <option value="20:00:00">20:00</option>
                                  </select>
                                </label><br>

                                <label class="d-flex " for="tratamiento">Tratamiento:
                                  <select class="select-css" name="Tratamiento" id="" required>
                                    <?php foreach ($trata as $dato5) { ?>
                                      <option id="Tratamiento" value="<?php echo $dato5->NOMBRE_TRATA ?>"><?php echo $dato5->NOMBRE_TRATA ?></option>
                                    <?php } ?>
                                  </select>
                                </label><br>

                                <label class="d-flex " for="equipo">Equipo:
                                  <select class="select-css" name="Equipo" id="" required>
                                    <?php foreach ($equipo as $dato4) { ?>
                                      <option id="Equipo" value="<?php echo $dato4->NOMBRE_EQUIPO ?>"><?php echo $dato4->NOMBRE_EQUIPO ?></option>
                                    <?php } ?>
                                  </select>
                                </label><br>



                                <label class="d-flex " for="zona">Zonas A Trabajar:
                                  <select class="select-css" name="Zona" id="" required>
                                    <?php foreach ($zona as $dato6) { ?>
                                      <option selected id="Zona" value="<?php echo $dato6->NOMBRE_ZONA ?>"><?php echo $dato6->NOMBRE_ZONA ?></option>
                                    <?php } ?>
                                  </select>
                                </label><br>

                                <label class="d-flex" for="Comentarios">Comentarios:
                                  <textarea style="    width: 76%;" name="Comentario" id="" cols="15" rows="1"></textarea>
                                </label>

                                <input class=" btn btn-dark btn-md mb-3 mt-3" style="margin-left: -20px;margin-right: -20px;" type="submit" id="turno" value="Agendar Turno" name="Turno">
                              </div>


                            </form>
                          </div>
                        </div>
                      </div>

                      <?php

  if (isset($_POST['Turno'])) {
    include 'model/conexion.php';

  
    $cedula = $_POST['Paciente_turno'];
    $sucursal = $_POST['Sucursal_turno'];
    $pacientename = $_POST['Paciente_turno'];
    $usuario = $_POST['profesional_truno'];

    $hora_ini = $_POST['Hora_Inicial'];
    $hora_fin = $_POST['Hora_Final'];
    $trata = $_POST['Tratamiento'];
    $zona = $_POST['Zona'];
    $equipo = $_POST['Equipo'];
    $fecha = $_POST['Fecha'];
    $coment = $_POST['Comentario'];


    if ($hora_ini == $hora_fin) {
    }
    if ($hora_ini > $hora_fin) {
    }


    $sql = "SELECT * FROM turnos WHERE HORA_INICIO >= ' $hora_ini ' AND HORA_FINAL <= ' $hora_fin ' AND FECHA = ' $fecha ' AND NOMBRE_SUCURSAL = '$sucursal'";
    $query = $con->prepare($sql);
    $query->execute();

    if ($query->rowCount() > 0) {
  ?>
      <div class="alert">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        ERROR: Existe un turno ya registrado en esos horarios, turno NO registrado.
      </div>
    <?php
    } else {

      $sql1 = "INSERT INTO turnos(FECHA,NOMBRE_PACIENTE,CEDULA_PACIENTE,NOMBRE_SUCURSAL,PROFESIONAL,HORA_INICIO,HORA_FINAL,TRATAMIENTO,EQUIPO,ZONA,COMENTARIOS) VALUES ('$fecha','$pacientename','$cedula','$sucursal','$usuario','$hora_ini','$hora_fin','$trata','$equipo','$zona','$coment')";
      $consulta = $con->prepare($sql1);
      $consulta->execute();
    ?>
      <script>
        window.onload = function() {
          document.getElementById("form1").submit();
          delay(100);
        }
      </script>
      <div class="alert-success">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        Turno creado con exito!
      </div>

  <?php

    }
  }



  ?>