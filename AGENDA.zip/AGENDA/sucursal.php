<?php include 'model/conexion.php';
    $consulta = $con->query("SELECT * FROM sucursal;");
    $sucursal = $consulta->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
<?php include 'navbar.php' ?>
    <div class="container bg-white mt-3">
        <div class="content row vh-10 justify-content-center align-items-center">
            <h1 class="text-center">Crear Nueva Sucursal</h1>
            <div class="col-auto">
            <form action="crear_sucursal.php" method="POST" autocomplete="false">

                
                    <label class="d-flex justify-content-center align-items-center" for="Nombre">Sucursal: 
                        <input class="form-control" type="text" name="Sucursal" id="sucursal" placeholder="Escribe la nueva Sucursal" required>
                        <input class="btn btn-dark btn-md mb-3 mt-3 " style="margin-left: 15px;" type="submit" value="Agregar Sucursal" name="Agregar_sucursal">
                    </label>
                
               
                
            </form>
            </div>
        </div>
    </div>

    <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////-->

    <div class="container bg-white mt-3">
        <h2 class="text-center">Sucursales Existentes</h2>
        <div class="content">
            <table style="margin:auto; width:55%; margin-bottom: 5vw;"  class="table table-hover table-bordered bg-light text-black" >
                <thead>
                    <th style="font-size: 23px;" >Nombre</th>

                    <th style="margin:auto; width:12%; font-size: 23px;">Acciones</th>
                </thead>
                <tbody>
                    <?php 
                        foreach($sucursal as $dato){
                    ?>
                    <tr style="background:white;">
                        
                        <td style="font-size: 20px;"><?php echo $dato->NOMBRE_SUCURSAL ?></td>
                        <td class="d-flex justify-content-center">
                       
                       <a href="eliminar_sucrusal.php?id=<?php echo $dato->ID_SUCURSAL ?>" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></a></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
