<?php
  if (isset($_POST['Agregar'])){
    include 'model/conexion.php';
    $nombre=$_POST['Nombre'];
    $apellido=$_POST['Apellido'];
    $telefono=$_POST['Telefono'];
    $cedula=$_POST['Cedula'];
    $direccion=$_POST['Direccion'];
    $email=$_POST['Email'];
    $sucursal_paciente=$_POST['Sucursal_turno'];

    $tamaño_img = $_FILES['foto_antes']['size'];
    $tipo_img = $_FILES['foto_antes']['type'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
        $fefe = @getimagesize($_FILES['foto_antes']['tmp_name']);
        if ($fefe !== false) {
            $carpeta_destino = 'img/';
            $archivo_subir = $carpeta_destino . $_FILES['foto_antes']['name'];
            $pejfoe = $_FILES['foto_antes']['name'];
            move_uploaded_file($_FILES['foto_antes']['tmp_name'], $archivo_subir);

            }
        }
/*
        $tamaño_img2 = $_FILES['foto_despues']['size'];        
        $tipo_img2 = $_FILES['foto_despues']['type'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
            $rdrd = @getimagesize($_FILES['foto_despues']['tmp_name']);
            if ($rdrd !== false) {
                $carpeta_destino2 = 'img/';
                $archivo_subir2 = $carpeta_destino2 . $_FILES['foto_despues']['name'];
                $pejfoe = $_FILES['foto_despues']['name'];
                move_uploaded_file($_FILES['foto_despues']['tmp_name'], $archivo_subir2);
    
            }
        }

if ($tamaño_img <= 3000000) {
    
    if ($tipo_img == "image/png" || $tipo_img == "image/jpg" || $tipo_img == "image/jpeg" || $tipo_img == "image/gif") {
     
    


    }else {
        ?>
      <div class="alert">
        <span><i class="fas fa-exclamation-triangle"></i></span>
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        ERROR: La foto Principal no es una foto.
      </div>
         <a href="pacientes.php">Volver</a>
    <?php
     exit;
    }
}
   

if ($tamaño_img2 <= 3000000) {
    
    if ($tipo_img2 == "image/png" || $tipo_img2 == "image/jpg" || $tipo_img2 == "image/jpeg" || $tipo_img2 == "image/gif") {

   
  }else {
    ?>
    <div class="alert">
      <span><i class="fas fa-exclamation-triangle"></i></span>
      <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
      ERROR: La segunda foto no es una foto
    </div>
    <a href="pacientes.php">Volver</a>
  <?php
      exit;
    
  }
}
*/
        
        //$imgContenido = addslashes(file_get_contents($_FILES['foto_antes']['tmp_name']));



   
    
    $consulta = $con->prepare("INSERT INTO pacientes(CEDULA_PACIENTE,NOMBRE_PACIENTE,APELLIDO_PACIENTE,SUCURSAL,DIRECCION_PACIENTE,TELEFONO_PACIENTE,EMAIL_PACIENTE,FOTO_ANTES_PACIENTE) VALUES(?,?,?,?,?,?,?,'$archivo_subir');");    
    $result = $consulta->execute([$cedula,$nombre,$apellido,$sucursal_paciente,$direccion,$telefono,$email]);
    if($result == true){
        header("Location: pacientes.php");
        
    }else{
        echo "no se pudo agregar el contacto";
    }
}

?>
