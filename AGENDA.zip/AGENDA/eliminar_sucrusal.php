<?php 
    if(!isset($_GET['id'])){
        header('Location: sucursal.php');
    }else{
        include('model/conexion.php');
        $id = $_GET['id'];

        $consulta = $con -> prepare("DELETE FROM sucursal WHERE ID_SUCURSAL=?;");
        $result = $consulta->execute([$id]);
    
        if($result == true){
            header('Location: sucursal.php');
        }else{
            echo "error de Eliminacion";
        }

}

?>