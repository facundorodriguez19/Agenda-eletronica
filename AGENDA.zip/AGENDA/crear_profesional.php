<?php
  if (isset($_POST['Agregar_Profesional'])){
    include 'model/conexion.php';
    $nombre_profesional=$_POST['nombre_profesional'];
    $sucursal_profesional=$_POST['Sucursal_turno'];
    $telefono_profesional=$_POST['telefono_profesional'];
    $email_profesional=$_POST['email_profesional'];


   /*
   $foto_profe = $_FILES['profesional']['size'];
   $foto_profe_tipo = $_FILES['profesional']['type'];
       
     
    

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
        $fefe = @getimagesize($_FILES['profesional']['tmp_name']);
        if ($fefe !== false) {
            $carpeta_destino3 = 'img2/';
            $archivo_subir3 = $carpeta_destino3 . $_FILES['profesional']['name'];
            move_uploaded_file($_FILES['profesional']['tmp_name'], $archivo_subir3);

            }
        }else {
        echo 'La primera Opcion No es una imagen, men mas cuidado';
        exit;
    }
*/




    $consulta = $con->prepare("INSERT INTO profesionales(NOMBRE_PROFESIONAL,SUCURSAL_PROFESIONAL,TELEFONO_PROFESIONAL,EMAIL_PROFESIONAL,FOTO_PROFESIONAL) VALUES(?,?,?,?,'$archivo_subir3');");    
    $result = $consulta->execute([$nombre_profesional,$sucursal_profesional,$telefono_profesional,$email_profesional]);
    if($result == true){
        header("Location: profesional.php");
    }else{
        echo "no se pudo agregar el contacto";
    }
}
  
?>