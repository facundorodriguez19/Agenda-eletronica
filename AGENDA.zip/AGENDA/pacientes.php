<?php include 'model/conexion.php';

session_start();

$consulta = $con->query("SELECT * FROM pacientes;");
$paciente = $consulta->fetchAll(PDO::FETCH_OBJ);

$consulta2 = $con->query("SELECT * FROM sucursal;");
$sucursal = $consulta2->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda ElECTRONICA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body style="background-color: #f2fbff;">
    <nav class="navbar-dark bg-white nav-bar-abajo ">
        <div class="nav-bar d-flex justify-content-around">

            <a class="ms-2 me-3 d-flex align-items-center" href="home_empleado.php"><i style="font-size:30px" class="fal fa-home-lg-alt"></i>&nbsp&nbsp<div class="d-lg-block d-none home pe-lg-3">Inicio</div></a>

            <a class=" me-3 d-flex align-items-center" href="pacientes.php"><i style="font-size:30px" class="fal fa-user-friends"></i>&nbsp&nbsp<div class="d-lg-block d-none pe-lg-3">Pacientes</div></a>

        </div>
    </nav>
    <input type="checkbox" id="btn-modal" value="">
        <div class="d-flex flex-row justify-content-center">
            <label for="btn-modal" class="d-flex boton_modal  btn-success" style="background-color: #4ed4bb;"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIw%0D%0AMDAvc3ZnIj4KCiA8Zz4KICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+CiAgPHJlY3QgZmlsbD0i%0D%0Abm9uZSIgaWQ9ImNhbnZhc19iYWNrZ3JvdW5kIiBoZWlnaHQ9IjQwMiIgd2lkdGg9IjU4MiIgeT0i%0D%0ALTEiIHg9Ii0xIi8+CiA8L2c+CiA8Zz4KICA8dGl0bGU+TGF5ZXIgMTwvdGl0bGU+CiAgPHBvbHln%0D%0Ab24gc3Ryb2tlPSIjZmZmZmZmIiBpZD0ic3ZnXzEiIHBvaW50cz0iODAuMiw1MS42IDUxLjQsNTEu%0D%0ANiA1MS40LDIyLjYgNDguOSwyMi42IDQ4LjksNTEuNiAxOS45LDUxLjYgMTkuOSw1NC4xIDQ4Ljks%0D%0ANTQuMSA0OC45LDgzLjEgICA1MS40LDgzLjEgNTEuNCw1NC4xIDgwLjQsNTQuMSA4MC40LDUxLjYg%0D%0AIiBmaWxsPSIjZmZmZmZmIi8+CiA8L2c+Cjwvc3ZnPg==" class="menu__trigger"></label>
        </div>
        <div class="modal">
            <div class="contenedor">
                <header>Agregar Paciente</header>

                <label for="btn-modal" style="position: absolute; color: white;"><i class="fas fa-times"></i></label>
                <div class="contenido">
                    <form action="crear_paciente.php" method="POST" autocomplete="false" enctype="multipart/form-data">
                        <div class="d-flex" style="flex-direction: column; align-items: flex-end;">
        
                                <label class="d-flex justify-content-center align-items-center" for="Cedula">Cedula:
                                    <input class="form-control" type="text" name="Cedula" id="cedula" placeholder="Escribe tu Cedula" required>
                                </label>
                           
                                <label style="margin-top: 5px;margin-bottom: 5px;" class="d-flex justify-content-center align-items-center" for="Nombre">Nombre:
                                    <input class="form-control" type="text" name="Nombre" id="nombre" placeholder="Escribe tu Nombre" required>
                                </label>
                           
                                <label class="d-flex justify-content-center align-items-center" for="Apellido">Apellido:
                                    <input class="form-control" type="text" name="Apellido" id="apellido" placeholder="Escribe tu Apellido" required>
                                </label>
                         
                                <label class="d-flex align-items-center " for="">Sucursal:
                                    <select class="select-css" style="width: 200px; margin-top: 5px;" name="Sucursal_turno" id="Sucursal_turno" required>
                                        <option id="Sucursal_turno" value="<?php echo $_SESSION['sucursal_seccion']; ?>"><?php echo $_SESSION['sucursal_seccion']; ?></option>
                                    </select>
                                </label>
                         
                          
                                <label style="margin-top: 5px;margin-bottom: 5px;" class="d-flex justify-content-center align-items-center" for="Telefono">Telefono/Celular:
                                    <input class="form-control" type="text" name="Telefono" id="telefono" placeholder="Escribe tu Telefono" required>
                                </label>
                         
                         
                                <label class="d-flex justify-content-center align-items-center" for="Direccion">Direccion:
                                    <input class="form-control" type="text" name="Direccion" id="direccion" placeholder="Escribe tu Direccion" required>
                                </label>
                            
                          
                                <label style="margin-top: 5px;margin-bottom: 5px;" class="d-flex justify-content-center align-items-center" for="Email">Email:
                                    <input class="form-control" type="Email" name="Email" id="email" placeholder="Escribe tu Email" required>
                                </label>
                           
                         
                                <label for="Foto">
                                    Foto Antes:
                                    <input type="file" size="20" name="foto_antes" required>
                                </label>
                                
                           
                           
                                <input class=" btn  btn-md mb-3 mt-3 btn_color_agregar posicion_btn_agregar_paciente" type="submit" value="Agregar Paciente" name="Agregar">
                                    
                        </div>
                </div>
                </form>

            </div>
        </div>
    <!--
        <label for="Foto">
                                    Foto Despues:
                                    <input type="file" size="20" name="foto_despues">
                                </label> 


                                -->

    

  
        <div class="container bg-white mt-3">
            <h2 class="text-center ">Pacientes Existentes</h2>
            <div class="content">
                <table class="table d-lg-block d-none table-bordered bg-light text-black" style="padding-bottom: 5vw;">
                    <thead>
                        <th style="font-size: 23px;">Cedula</th>
                        <th style="font-size: 23px;">Nombre</th>
                        <th style="font-size: 23px;">Apellido</th>
                        <th style="font-size: 23px;">Telefono</th>
                        <th style="font-size: 23px;">Direccion</th>
                        <th style="font-size: 23px;">Email</th>
                        <th style="font-size: 23px;">Foto Antes</th>
                        <th style="font-size: 23px;">Foto Despues</th>
            
                        <th style="width: 8%;font-size: 23px;">Acciones</th>

                    </thead>
                    <tbody>
                        <?php
                        foreach ($paciente as $dato) {
                            if ($_SESSION['sucursal_seccion'] == $dato->SUCURSAL) {


                        ?>
                                <tr style="background:white;">
                                    <td style="font-size: 20px;"><?php echo $dato->CEDULA_PACIENTE ?></td>
                                    <td style="font-size: 20px;"><?php echo $dato->NOMBRE_PACIENTE ?></td>
                                    <td style="font-size: 20px;"><?php echo $dato->APELLIDO_PACIENTE ?></td>
                                    <td style="font-size: 20px;"><?php echo $dato->TELEFONO_PACIENTE ?></td>
                                    <td style="font-size: 20px;"><?php echo $dato->DIRECCION_PACIENTE ?></td>
                                    <td style="font-size: 20px;"><?php echo $dato->EMAIL_PACIENTE ?></td>
                                    <td><img style="width: 70%;" src="<?php echo $dato->FOTO_ANTES_PACIENTE ?>" alt="" srcset=""></td>
                                    <td><img style="width: 70%;" src="<?php echo $dato->FOTO_DESPUES_PACIENTE ?>" alt="" srcset=""></td>
                                  
                                    <td class="d-flex flex-row flex-nowrap"><a href="editar_paciente.php?id=<?php echo $dato->ID_PACIENTE ?>" class="btn  btn-warning me-1"><i class="fas fa-marker"></i></a>
                                        <a href="eliminar_paciente.php?id=<?php echo $dato->ID_PACIENTE ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>

                        <?php }
                        } ?>
                    </tbody>
                </table>
                <table class=" d-lg-none d-block table table-bordered bg-light text-black" style="padding-bottom: 5vw;" >
                    <thead>
                        <th style="font-size: 14px;">Cedula</th>
                        <th style="font-size: 14px;">Nombre</th>
                        <th style="font-size: 14px;">Telefono</th>
                        <th style="width: 8%; font-size: 14px;">Acciones</th>

                    </thead>
                    <tbody>
                        <?php
                        foreach ($paciente as $dato) {
                            if ($_SESSION['sucursal_seccion'] == $dato->SUCURSAL) {
                        ?>
                                <tr style="background:white;">
                                    <td style="font-size: 10px;"><?php echo $dato->CEDULA_PACIENTE ?></td>
                                    <td style="font-size: 10px;"><?php echo $dato->NOMBRE_PACIENTE ?></td>
                                    <td style="font-size: 10px;"><?php echo $dato->TELEFONO_PACIENTE ?></td>
                                    <td style="width: ;" class="d-flex flex-row flex-nowrap"><a href="editar_paciente.php?id=<?php echo $dato->ID_PACIENTE ?>" class="btn btn-warning me-1"><i class="fas fa-marker"></i></a>
                                        <a href="eliminar_paciente.php?id=<?php echo $dato->ID_PACIENTE ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>

                        <?php }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
   




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>