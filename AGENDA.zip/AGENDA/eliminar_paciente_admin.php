<?php 
    if(!isset($_GET['id'])){
        header('Location: pacientes_admin.php');
    }else{
        include('model/conexion.php');
        $id = $_GET['id'];

        $consulta = $con -> prepare("DELETE FROM pacientes WHERE ID_PACIENTE=?;");
        $result = $consulta->execute([$id]);
    
        if($result == true){
            header('Location: pacientes_admin.php');
        }else{
            echo "error de Eliminacion";
        }

}

?>