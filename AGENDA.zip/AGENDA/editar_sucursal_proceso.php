<?php 
    if(!isset($_POST['Editar_SUC'])){
        header('Location: sucursal.php');
    }else{
        include('model/conexion.php');
        $nombre=$_POST['Sucursal'];
        $id = $_POST['id4'];

        $consulta = $con -> prepare("UPDATE sucursal SET NOMBRE_SUCURSAL=? WHERE ID_SUCURSAL=?;");
        $result = $consulta->execute([$nombre,$id]);
    
    if($result == true){
        header('Location: sucursal.php');
    }else{
        echo "error de actualizacion";
    }

}

?>