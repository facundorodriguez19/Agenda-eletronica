<?php 

session_start();


include 'model/conexion.php';

error_reporting(0);

if (!empty($_POST['nombre_usuario']) && !empty($_POST['log_password'])) {
    $records = $con->prepare('SELECT * FROM usuarios WHERE USUARIO = :user');
    $records->bindParam(':user', $_POST['nombre_usuario']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

    if (count($results) > 0 && password_verify($_POST['log_password'], $results['CLAVE'])) {
      $_SESSION['user_id'] = $results['ID_USUARIO'];
      $_SESSION['usuario_seccion'] = $results['USUARIO'];
      $_SESSION['sucursal_seccion'] = $results['SUCURSAL'];
      $_SESSION['permiso_seccion'] = $results['PERMISO'];
      header("Location: home_empleado.php");
    } else {
      $message = 'Perdon';
    }
    if ($_POST['nombre_usuario'] == "ADMIN" && $_POST['log_password'] == "ADMIN") {
      header("Location: home.php");
    }
    

    }

    

    
    
    ?>

   




  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos_login.css">
    <title>Login</title>
</head>
<body>
    <h1 class="margin_h1">Login:</h1>

    <?php if (!empty($message)):?>
        <p class="alert alert-danger" role="alert"><?= $message ?>, pero el usuario o la clave son incorrectas</p>
    <?php endif ?>  
   
    <form class="index_login" action="index.php" method="POST">
        <input type="text" name="nombre_usuario" placeholder="Ingrese su Nombre">
        <input type="password" name="log_password" placeholder="Ingrese su Contraseña">
        <input type="submit" value="Enviar">
        </form>
        <a href="registrarse.php">Registrar Nueva Cuenta</a>
       
</body>
</html>