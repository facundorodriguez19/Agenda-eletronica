<?php 
    if(!isset($_POST['Editar_pro'])){
        header('Location: profesional.php');
    }else{
        include('model/conexion.php');
        $nom_profesional=$_POST['Nombre_profesional'];
        $sucu_profesional=$_POST['Sucursal_turno'];
        $tele_profesional=$_POST['Telefono_profesional'];
        $ema_profesional=$_POST['Email_profesional'];
        $id = $_POST['id3'];

        $consulta = $con -> prepare("UPDATE profesionales SET NOMBRE_PROFESIONAL=?,SUCURSAL_PROFESIONAL=?,TELEFONO_PROFESIONAL=?,EMAIL_PROFESIONAL=? WHERE ID_PROFESIONAL=?;");
        $result = $consulta->execute([$nom_profesional,$sucu_profesional,$tele_profesional,$ema_profesional,$id]);
    
    if($result == true){
        header('Location: profesional.php');
    }else{
        echo "error de actualizacion";
    }

}

?>