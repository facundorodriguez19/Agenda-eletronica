<?php
//
//if (isset($_POST['Turno'])){
//  include 'model/conexion.php';
//
//
//  $sucursal=$_POST['Sucursal_turno'];
//  $paciente=$_POST['Paciente_turno'];
//  $usuario=$_POST['Usuario_truno'];
//  $cate_zona=$_POST['categoria_Zonas'];
//  $hora_ini=$_POST['Hora_Inicial'];
//  $hora_fin=$_POST['Hora_Final'];
//  $trata=$_POST['Tratamiento'];
//  $zona=$_POST['Zona'];
//  $equipo=$_POST['Equipo'];
//  $fecha=$_POST['Fecha'];
////  $coment=$_POST['Comentario'];
////  
////
////
////
////  if ($hora_ini > $hora_fin) {
////    echo '<div class="alert alert-success">Thank You!now please login </div>';
////  exit;
////  }
////  if ($hora_ini == $hora_fin) {
////      echo '<div class="alert alert-danger"> La hora INICIAL debe ser diferente a la HORA FINAL.</div>';
////      exit;
////  }
////
//  
//$consulta = $con->prepare("INSERT INTO turnos(FECHA,NOMBRE_PACIENTE,NOMBRE_SUCURSAL,PROFESIONAL,HORA_INICIO,HORA_FINAL,TRATAMIENTO,EQUIPO,CATEGORIA_ZONA,ZONA,COMENTARIOS) VALUES(?,?,?,?,?,?,?,?,?,?,?);");    
//  $result = $consulta->execute([$fecha,$paciente,$sucursal,$usuario,$hora_ini,$hora_fin,$trata,$equipo,$cate_zona,$zona,$coment]);
//  
//  if($result == true ){ 
//    header("Location: home.php");
//    echo("<meta http-equiv='refresh' content='1'>");
//  }else{
//      echo "agrega bien los turnos cabeza de chorlito";
//      exit;
//  }//
//}

//  
?>