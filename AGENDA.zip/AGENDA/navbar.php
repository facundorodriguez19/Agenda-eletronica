<nav class="navbar-dark bg-white nav-bar-abajo " style="z-index: 5;" >
    <div class="nav-bar d-flex justify-content-around ">

        <a  class="ms-2 me-3 d-flex align-items-center"  href="home.php"><i style="font-size:30px" class="fal fa-home-lg-alt"></i>&nbsp&nbsp<div class="d-lg-block d-none home pe-lg-3">Inicio</div></a>

        <a class=" me-3 d-flex align-items-center"  href="pacientes_admin.php"><i style="font-size:30px" class="fal fa-user-friends"></i>&nbsp&nbsp<div class="d-lg-block d-none pe-lg-3">Pacientes</div></a>
        <div></div>
        <a id="usu_permiso" class=" me-3 d-flex align-items-center" href="profesional.php"><i style="font-size:30px" class="fal fa-user-md"></i>&nbsp&nbsp<div class="d-lg-block d-none pe-lg-3">Profesionales</div></a>

        <a id="sucu_permiso" class=" me-3 d-flex align-items-center" href="sucursal.php"><i style="font-size:30px" class="fal fa-building "></i>&nbsp&nbsp<div class="d-lg-block d-none pe-lg-3">Sucursales</div></a>

       
    </div>
</nav>



